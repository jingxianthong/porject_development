// new_class_script.js

// Function to handle click on Share Screen button
document.getElementById("shareScreenButton").addEventListener("click", function() {
    // Your code to initiate screen sharing goes here
    alert("Initiating screen sharing...");
});

// Function to handle click on Open Camera button
document.getElementById("openCameraButton").addEventListener("click", function() {
    // Your code to open the camera goes here
    alert("Opening camera...");
});
